package ua.pt.naturespot.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import ua.pt.naturespot.R;

public class Fragment_ModeratorOptions_Reports extends Fragment {

    private static final String TAG = "YOYO";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        getActivity().setTitle("Moderator Options");

        // BEGIN: Hiding Floating Action Button
        FloatingActionButton fab = getActivity().findViewById(R.id.fab);
        fab.hide();
        // End:   Hiding Floating Action Button


        View view = inflater.inflate(R.layout.fragment_moderatoractions_reports,container, false);


        return view;
    }


}
