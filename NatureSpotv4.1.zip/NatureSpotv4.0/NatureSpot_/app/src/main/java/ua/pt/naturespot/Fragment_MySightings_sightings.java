package ua.pt.naturespot;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class Fragment_MySightings_sightings extends Fragment {

    RecyclerView mRecyclerView;
    List< SightingsData > mSightingList;
    SightingsData mSightingData;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mysightings_sightings, container, false);

        mRecyclerView = view.findViewById(R.id.listSightings);
        GridLayoutManager mGridLayoutManager = new GridLayoutManager(getActivity(), 3);
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        mSightingList = new ArrayList<>();

        mSightingData = new SightingsData("Cágado","É muito bonito" ,"Viseu" ,R.drawable.pictureanimal3);
        mSightingList.add(mSightingData);

        mSightingData = new SightingsData("Iguana","É muito bonita" ,"Aveiro" ,R.drawable.pictureanimal4);
        mSightingList.add(mSightingData);

        MyAdapter myAdapter = new MyAdapter(getActivity(), mSightingList);
        mRecyclerView.setAdapter(myAdapter);
        return view;
    }

  }
