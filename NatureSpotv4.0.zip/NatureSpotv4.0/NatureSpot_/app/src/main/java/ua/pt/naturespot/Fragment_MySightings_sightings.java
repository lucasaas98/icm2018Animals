package ua.pt.naturespot;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class Fragment_MySightings_sightings extends Fragment {

    RecyclerView mRecyclerView;
    List< SightingsData > mSightingList;
    SightingsData mSightingData;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mysightings_sightings, container, false);

        mRecyclerView = view.findViewById(R.id.listSightings);
        GridLayoutManager mGridLayoutManager = new GridLayoutManager(getActivity(), 3);
        mRecyclerView.setLayoutManager(mGridLayoutManager);


        mSightingList = new ArrayList<>();
        mSightingData = new SightingsData("Lobo","É muito bonito" ,"Viseu" ,R.drawable.pictureanimal1);
        mSightingList.add(mSightingData);

        mSightingData = new SightingsData("Cão","É muito bonito" ,"Viseu" ,R.drawable.pictureanimal2);
        mSightingList.add(mSightingData);

        mSightingData = new SightingsData("Lobo","É muito bonito" ,"Viseu" ,R.drawable.pictureanimal3);
        mSightingList.add(mSightingData);

        MyAdapter myAdapter = new MyAdapter(getActivity(), mSightingList);
        mRecyclerView.setAdapter(myAdapter);

        /*
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.listSightings);

        MyAdapter myAdapter = new MyAdapter();

        recyclerView.setAdapter(myAdapter);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        */
        return view;
    }

  }
