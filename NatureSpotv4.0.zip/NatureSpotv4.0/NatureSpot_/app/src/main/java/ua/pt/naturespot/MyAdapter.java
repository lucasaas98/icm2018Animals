package ua.pt.naturespot;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<ListViewHolder> {

    private Context mContext;
    private List<SightingsData> mSightingsList;

    MyAdapter(Context mContext, List< SightingsData > mSightingsList) {
        this.mContext = mContext;
        this.mSightingsList = mSightingsList;
    }

    @Override
    public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sightings, parent, false);
        return new ListViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(final ListViewHolder holder, int position) {
        holder.mImage.setImageResource(mSightingsList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return mSightingsList.size();
    }
}

class ListViewHolder extends RecyclerView.ViewHolder {

    ImageView mImage;

    ListViewHolder(View itemView) {
        super(itemView);

        mImage = itemView.findViewById(R.id.ivImage);
    }
}
