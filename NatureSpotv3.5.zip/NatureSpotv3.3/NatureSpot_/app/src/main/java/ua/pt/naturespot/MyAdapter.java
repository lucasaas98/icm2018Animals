package ua.pt.naturespot;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<ListViewHolder> {

    private Context mContext;
    private List<SightingsData> mSightingsList;

    MyAdapter(Context mContext, List< SightingsData > mSightingsList) {
        this.mContext = mContext;
        this.mSightingsList = mSightingsList;
    }

    @Override
    public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sightings, parent, false);
        return new ListViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(final ListViewHolder holder, int position) {
        holder.mImage.setImageResource(mSightingsList.get(position).getImage());
        holder.mTitle.setText(mSightingsList.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return mSightingsList.size();
    }
}

class ListViewHolder extends RecyclerView.ViewHolder {

    ImageView mImage;
    TextView mTitle;

    ListViewHolder(View itemView) {
        super(itemView);

        mImage = itemView.findViewById(R.id.ivImage);
        mTitle = itemView.findViewById(R.id.tvTitle);
    }
}


    /*@NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sightings, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ListViewHolder) holder).bindView(position);
    }

    @Override
    public int getItemCount() {
        return OurData.picturePath.length;
    }

    private class ListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private ImageView mItemImage;

        public ListViewHolder(View itemView) {
            super(itemView);
            mItemImage = (ImageView) itemView.findViewById(R.id.itemSightings);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {

        }

        public void bindView(int position) {
            System.out.println("POSITION: "+position);
            mItemImage.setImageResource(OurData.picturePath[position]);
        }
    }
    */

