package ua.pt.naturespot.Fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import ua.pt.naturespot.Activities.MapsActivity;
import ua.pt.naturespot.Adapters.MyAdapter;
import ua.pt.naturespot.Model.OurData;
import ua.pt.naturespot.Model.SightingsData;
import ua.pt.naturespot.R;

import static ua.pt.naturespot.Activities.MainActivity.EXTRA_MESSAGE;

public class Fragment_MySightings_species extends Fragment {
    //private List<String> StringArray = new ArrayList<>();
    //private List<String> StringArray2 = new ArrayList<>();
    //private List<Bitmap> BitMapArray = new ArrayList<>();

    ArrayList<SightingsData> mSightingList;
    private static final String TAG = "YOYO";
    private ListView listView;
    private HashMap<String, ArrayList<SightingsData>> map = new HashMap<>();

    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReferenceFromUrl("gs://naturespot-3e30f.appspot.com");

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_mysightings_species, null);
        listView = (ListView) view.findViewById(R.id.listView1);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        createData();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if(isVisibleToUser) {
            createData();
        } else {
            //DO SOMETHING :)))
        }

    }

    public void createData() {
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference dbRef= db.getReference();
        final String uuid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                mSightingList = new ArrayList<>();

                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                DataSnapshot here = dataSnapshot.child("Sightings").child(uuid).child("sightings");

                for(DataSnapshot fin : here.getChildren()){
                    String name = (String) fin.child("name").getValue();
                    String data = (String) fin.child("date").getValue();
                    String description = (String) fin.child("description").getValue();
                    String location = (String) fin.child("location").getValue();
                    String imageUrl = (String) fin.child("photoURL").getValue();
                    String species = (String) fin.child("species").getValue();
                    String species_fancy =(String) fin.child("species_fancy").getValue();
                    String id = fin.getKey();

                    SightingsData sd = new SightingsData(name, description, location, imageUrl, data, id, here.getKey(), species, species_fancy);
                    mSightingList.add(sd);

                    ArrayList<SightingsData> s;
                    if (!map.containsKey(species_fancy)) {
                        s = new ArrayList<>();
                        s.add(sd);
                    } else {
                        s = map.get(species_fancy);
                        s.add(sd);
                    }
                    map.put(species_fancy, s);

                }
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });



        // Construct the data source
        ArrayList<String> arrayOfUsers = new ArrayList<>();
        // Create the adapter to convert the array to views
        Fragment_MySightings_species.UsersAdapter adapter = new Fragment_MySightings_species.UsersAdapter(getContext(), arrayOfUsers, mSightingList);
        if(mSightingList!=null)
            for (SightingsData elem : mSightingList){
                adapter.add(elem.getName());
            }
        // Attach the adapter to a ListView
        listView.setAdapter(adapter);

    }

    public class UsersAdapter extends ArrayAdapter<String> {
        private ArrayList<SightingsData> mSightingsList;

        public UsersAdapter(Context context, ArrayList<String> users, ArrayList<SightingsData> mSightingsList) {
            super(context, 0, users);
            this.mSightingsList = mSightingsList;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = null;
            StorageReference storageRef = storage.getReferenceFromUrl("gs://naturespot-3e30f.appspot.com");
            storageRef = storageRef.child(mSightingsList.get(position).getImage());

            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_species, parent, false);
            }

            // Lookup view for data population
            TextView tvName = (TextView) convertView.findViewById(R.id.animalName);
            TextView tvName2 = (TextView) convertView.findViewById(R.id.animalSpecies);
            final ImageView imageView2 = (ImageView) convertView.findViewById(R.id.imageView2);
            CardView card_view = (CardView) convertView.findViewById(R.id.cardView2);

            // Get the data item for this position
            String user = getItem(position);




            card_view.setTag(position);
            card_view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = (Integer) view.getTag();
                    Intent nice = new Intent(getActivity().getBaseContext(), MapsActivity.class);
                    String message = "40.6405, -8.6538"; // "lat, long! lat, long! lat, long!"
                    nice.putExtra(EXTRA_MESSAGE, message);
                    startActivity(nice);
                }
            });

            try {
                final File localFile = File.createTempFile("image", "jpg");
                storageRef.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                        Bitmap bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
                        imageView2.setImageBitmap(bitmap);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        Log.d("FAIL: ", "FAIL");
                    }
                });
                localFile.delete();
            } catch (IOException e ) {}



            tvName.setText(user);
            tvName2.setText(mSightingList.get(position).getSpecies());
            return convertView;
        }
    }
}