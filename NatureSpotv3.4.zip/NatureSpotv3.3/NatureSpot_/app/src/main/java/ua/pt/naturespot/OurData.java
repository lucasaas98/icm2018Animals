package ua.pt.naturespot;

public class OurData {

    public static int[] picturePath = new int[] {
            R.drawable.pictureanimal1,
            R.drawable.pictureanimal2,
            R.drawable.pictureanimal3,
            R.drawable.pictureanimal3
    };
}
