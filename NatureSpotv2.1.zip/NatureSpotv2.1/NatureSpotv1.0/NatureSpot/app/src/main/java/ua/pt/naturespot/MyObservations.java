package ua.pt.naturespot;


import android.support.v4.app.Fragment;



public class MyObservations extends SingleFragment {

    @Override
    protected Fragment createFragment() {
        return  new RecyclerFragment().newInstance();
    }
}
